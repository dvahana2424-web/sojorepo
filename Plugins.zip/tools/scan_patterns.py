#!/usr/bin/env python3
"""Scan Steam DLLs for Hammer signature patterns and emit new .toml files."""

from __future__ import annotations

import re
import struct
import sys
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path


FNV_OFFSET = 0x811C9DC5
FNV_PRIME = 0x01000193


def fnv1a(name: str) -> int:
    h = FNV_OFFSET
    for c in name.encode():
        h ^= c
        h = (h * FNV_PRIME) & 0xFFFFFFFF
    return h


@dataclass
class Pattern:
    key: int
    name: str
    rva: str
    sig: str


@dataclass
class Section:
    va: int
    vs: int
    raw: int
    rs: int


def parse_toml_patterns(path: Path) -> list[Pattern]:
    text = path.read_text(encoding="utf-8")
    patterns: list[Pattern] = []
    for block in re.split(r"\n(?=\[0x)", text.strip()):
        if not block.strip():
            continue
        key_match = re.match(r"\[0x([0-9A-Fa-f]+)\]", block)
        name_match = re.search(r'name\s*=\s*"([^"]+)"', block)
        rva_match = re.search(r'rva\s*=\s*"(0x[0-9A-Fa-f]+)"', block)
        sig_match = re.search(r'sig\s*=\s*"([^"]+)"', block)
        if not all([key_match, name_match, rva_match, sig_match]):
            continue
        patterns.append(
            Pattern(
                key=int(key_match.group(1), 16),
                name=name_match.group(1),
                rva=rva_match.group(1),
                sig=sig_match.group(1),
            )
        )
    return patterns


def parse_sig(sig: str) -> tuple[bytes, bytes]:
    parts = sig.split()
    pattern = bytearray()
    mask = bytearray()
    for part in parts:
        if part == "??":
            pattern.append(0)
            mask.append(0)
        else:
            pattern.append(int(part, 16))
            mask.append(0xFF)
    return bytes(pattern), bytes(mask)


def load_pe_image(path: Path) -> tuple[bytes, list[Section]]:
    data = path.read_bytes()
    if data[:2] != b"MZ":
        raise ValueError(f"{path} is not a PE file")

    pe_off = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe_off : pe_off + 4] != b"PE\x00\x00":
        raise ValueError(f"{path} has invalid PE signature")

    num_sections = struct.unpack_from("<H", data, pe_off + 6)[0]
    opt_hdr_size = struct.unpack_from("<H", data, pe_off + 20)[0]
    opt_off = pe_off + 24
    magic = struct.unpack_from("<H", data, opt_off)[0]
    if magic != 0x20B:
        raise ValueError(f"{path} is not PE32+")

    image_size = struct.unpack_from("<I", data, opt_off + 56)[0]
    image = bytearray(image_size)
    section_off = opt_off + opt_hdr_size
    sections: list[Section] = []

    for i in range(num_sections):
        off = section_off + i * 40
        name = data[off : off + 8].split(b"\x00", 1)[0]
        vs, va, rs, raw = struct.unpack_from("<IIII", data, off + 8)
        sec = Section(va=va, vs=vs, raw=raw, rs=rs)
        sections.append(sec)
        chunk = data[raw : raw + min(rs, vs)]
        end = min(va + len(chunk), image_size)
        image[va:end] = chunk[: end - va]

    return bytes(image), sections


def scan_pattern(image: bytes, pattern: bytes, mask: bytes) -> list[int]:
    hits: list[int] = []
    plen = len(pattern)
    if plen == 0 or plen > len(image):
        return hits
    for i in range(len(image) - plen + 1):
        ok = True
        for j in range(plen):
            if mask[j] and image[i + j] != pattern[j]:
                ok = False
                break
        if ok:
            hits.append(i)
    return hits


def extract_sig_at(image: bytes, rva: int, length: int) -> str:
    chunk = image[rva : rva + length]
    return " ".join(f"{b:02X}" for b in chunk)


def resolve_pattern(
    image: bytes,
    pat: Pattern,
    old_image: bytes | None = None,
    old_rva: int | None = None,
) -> tuple[int | None, str, str]:
    pattern, mask = parse_sig(pat.sig)
    hits = scan_pattern(image, pattern, mask)

    if len(hits) == 1:
        rva = hits[0]
        sig = extract_sig_at(image, rva, len(pattern))
        return rva, sig, "unique"

    if len(hits) == 0:
        return None, pat.sig, "missing"

    # Multiple hits: prefer closest to old RVA if available.
    if old_rva is not None:
        rva = min(hits, key=lambda h: abs(h - old_rva))
        sig = extract_sig_at(image, rva, len(pattern))
        return rva, sig, f"nearest({len(hits)} hits)"

    # Fall back to first hit but flag it.
    rva = hits[0]
    sig = extract_sig_at(image, rva, len(pattern))
    return rva, sig, f"first({len(hits)} hits)"


def write_toml(path: Path, entries: list[tuple[Pattern, int, str]]) -> None:
    lines: list[str] = []
    for pat, rva, sig in entries:
        key = fnv1a(pat.name)
        if key != pat.key:
            print(f"  warning: key mismatch for {pat.name}: file={pat.key:#x} fnv1a={key:#x}")
        lines.append(f"[0x{key:08X}]")
        lines.append(f'name = "{pat.name}"')
        lines.append(f'rva = "0x{rva:X}"')
        lines.append(f'sig = "{sig}"')
        lines.append("")
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def sha256_file(path: Path) -> str:
    h = sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def pick_reference_toml(pattern_dir: Path) -> Path:
    files = sorted(pattern_dir.glob("*.toml"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        raise FileNotFoundError(f"No .toml files in {pattern_dir}")
    return files[0]


def generate(
    dll_path: Path,
    ref_toml: Path,
    out_dir: Path,
    old_dll_path: Path | None = None,
) -> Path:
    print(f"\n==> {dll_path.name}")
    print(f"    reference: {ref_toml.name}")

    patterns = parse_toml_patterns(ref_toml)
    image, _ = load_pe_image(dll_path)
    old_image = None
    if old_dll_path and old_dll_path.exists():
        old_image, _ = load_pe_image(old_dll_path)

    entries: list[tuple[Pattern, int, str]] = []
    missing: list[str] = []
    ambiguous: list[str] = []

    for pat in patterns:
        old_rva = int(pat.rva, 16)
        old_rva_for_match = old_rva if old_image is not None else None
        rva, sig, status = resolve_pattern(image, pat, old_image, old_rva_for_match)
        if rva is None:
            missing.append(pat.name)
            print(f"  MISS  {pat.name}")
            continue
        if status != "unique":
            ambiguous.append(f"{pat.name} ({status})")
        print(f"  OK    {pat.name}: {pat.rva} -> 0x{rva:X} [{status}]")
        entries.append((pat, rva, sig))

    digest = sha256_file(dll_path)
    out_path = out_dir / f"{digest}.toml"
    write_toml(out_path, entries)

    print(f"    wrote: {out_path}")
    print(f"    sha256: {digest}")
    print(f"    resolved: {len(entries)}/{len(patterns)}")
    if missing:
        print(f"    missing: {', '.join(missing)}")
    if ambiguous:
        print(f"    ambiguous: {', '.join(ambiguous)}")

    return out_path


def main() -> int:
    steam = Path(r"C:\Program Files (x86)\Steam")
    hammer_pattern = Path(r"C:\Program Files (x86)\Steam\Hammer\pattern")
    workspace_pattern = Path(__file__).resolve().parents[1] / "Hammer" / "pattern"

    targets = [
        (
            steam / "steamclient64.dll",
            hammer_pattern / "steamclient",
            workspace_pattern / "steamclient",
        ),
        (
            steam / "SteamUI.dll",
            hammer_pattern / "steamui",
            workspace_pattern / "steamui",
        ),
    ]

    for dll_path, install_dir, workspace_dir in targets:
        ref_dir = workspace_dir if workspace_dir.exists() else install_dir
        ref_toml = pick_reference_toml(ref_dir)
        out_dir = install_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = generate(dll_path, ref_toml, out_dir)
        workspace_dir.mkdir(parents=True, exist_ok=True)
        workspace_out = workspace_dir / out_path.name
        workspace_out.write_text(out_path.read_text(encoding="utf-8"), encoding="utf-8")

    return 0


if __name__ == "__main__":
    sys.exit(main())
